<?php
include '../pruebas_cono/chat_ajax/db.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<title>Ejemplo</title>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
    .container{padding: 50px;}
    .cart-link{width: 100%;text-align: right;display: block;font-size: 22px;}
    </style>
</head>
<body>
<div class="container">
	<h1>Productos</h1>
	<a href="verCarrito.php" class="cart-link" title="Ver carro"><i class="glyphicon glyphicon-shopping-cart"></i></a>
	<div id="products" class="row list-group">
		<?php 
		 $query = $conexion->query("SELECT productos.name AS nombre, productos.id, productos.description, productos.price, productos.id_category, categoria.id, categoria.name FROM `productos`,`categoria` WHERE categoria.id=productos.id_category ORDER BY productos.id");
        if($row=$query->fetch_array()){ 
            do{
        ?>

	<div class="item col-lg-4">
		<div class="thumbnail">
			<div class="caption">
				<h4 class="list-group-item-heading"><?php echo $row["nombre"];?></h4>
				<p class="list-group-item-text"><?php echo "Categoria: ".$row["name"];?></p>
				<p class="list-group-item-text"><?php echo $row["description"];?></p>
				<div class="row">
					<div class="col-md-6">
						<p class="lead"><?php echo '$'.$row['price'];?></p>
					</div>
					<!--<div class="col-md-6">
						<a class="btn btn-success" href="AccionCarro.php?action=addToCart&id=<?//php echo $row["id"]; ?>">Add to cart</a"></a>
					</div>-->
				</div>
			</div>
		</div>
	</div>
	<?php }while($row=$query->fetch_array()); 
	} else{ ?>
		<p>Producto no encontrado....</p>
	<?php } ?>
	
</div>
</div>
</body>
</html>