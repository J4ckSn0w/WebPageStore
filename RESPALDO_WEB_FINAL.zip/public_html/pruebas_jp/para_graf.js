var datos=[];
var nombres=[];
var myColor = ['red', 'green', 'blue','yellow','#1C62C4','#848484'];
var total=0;
function insertar(x,y){
	datos.push(x);
	total+=parseInt(x);
	nombres.push(y);
}
function graf(){
	console.log(total);
	console.log(datos.length);
	var canvas = document.getElementById('canv');
	var ctx = canvas.getContext('2d');
	var ult = 0;
	for (var i = 0; i < datos.length; i++) {
		ctx.fillStyle = myColor[i];
		ctx.beginPath();
		ctx.arc(canvas.width / 2, canvas.height / 2, canvas.height / 2, ult, ult + (Math.PI * 2 * (datos[i] / total)));
		ctx.lineTo(canvas.width / 2, canvas.height / 2);
		ctx.fill();
		ult += Math.PI * 2 * (datos[i] / total);
	}
}
