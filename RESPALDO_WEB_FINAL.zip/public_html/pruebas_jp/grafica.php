<!DOCTYPE html>
<html>
<head>
	
	<script src="para_graf.js"></script>
</head>
<body>
	<?php
	include '../pruebas_cono/chat_ajax/db.php';
	$sql="SELECT categoria.name,SUM(detalle_orden.quantity) as suma FROM `detalle_orden`,`productos`,`categoria` WHERE categoria.id=productos.id_category and detalle_orden.product_id = productos.id GROUP BY categoria.id";
	$result=$conexion->query($sql);
	if($row=$result->fetch_array()){
		do{
	?> <script>
		insertar(<?php echo $row['suma']?>,<?php echo $row['name']?>);
		uno();
	</script>		
	<?php	}while($row=$result->fetch_array());
	}
	?>
	<script>
		graf();
	</script>
	<?php echo "<canvas id='canv' width='300' height='300'></canvas>"; ?>
</body>
</html>

