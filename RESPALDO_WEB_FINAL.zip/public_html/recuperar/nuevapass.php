<?php
	include "db.php";
	$pass1 = md5($_POST['pass1']);
	$pass2 = md5($_POST['pass2']);
	$correo = $_GET['correo'];
	$cliente = $_GET['cliente'];
	if(strcmp($pass1, $pass2) == 0){
			$consulta = $conexion->query("UPDATE `clientes` SET `password`= '$pass1'  WHERE `id` = '$cliente'");
			$destinatario = $correo; 
			$asunto = "Tu contraseña ha sido cambiada"; 
			$cuerpo = '<h3>Estimado cliente tu contraseña ha sido cambiada por '.$_POST['pass1'].'</h3>'; 
			//para el envío en formato HTML 
			$headers = "MIME-Version: 1.0\r\n"; 
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
			//dirección del remitente 
			$headers .= "From: JPStore <conoelmarginado@outlook.com>\r\n"; 
			//dirección de respuesta, si queremos que sea distinta que la del remitente 
			$headers .= "Reply-To: conoelmarginado@outlook.com\r\n"; 
			//ruta del mensaje desde origen a destino 
			$headers .= "Return-path: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibián copia 
			$headers .= "Cc: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibirán copia oculta 
			$headers .= "Bcc: conoelmarginado@outlook.com\r\n"; 
			mail($destinatario,$asunto,$cuerpo,$headers);
		echo '<script>alert("Contraseña cambiada")</script>
			  <script>window.location="/login.php"</script>';
	}else{
		echo '<script>alert("Las contraseñas no coinciden")</script>
			  <script>window.location="preguntas_msj.php?correo='.$correo.'&cliente='.$cliente.'"</script>';
	}
?>