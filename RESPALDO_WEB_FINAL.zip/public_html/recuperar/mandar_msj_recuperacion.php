<?php
		include "db.php";
		$correo = $_POST['email'];
		$consulta = $conexion->query("SELECT * FROM `clientes` WHERE `email` = '$correo'");
		if($f = $consulta->fetch_array()){
			$destinatario = $correo; 
			$cliente = $f['id'];
			$asunto = "Recuperación de Contraseña "; 
			$cuerpo = "<h1>Ingrese al sieguiente <a href='https://conoelmarginado.000webhostapp.com/recuperar/preguntas_msj.php?correo=$correo&cliente=$cliente'> enlace </a>  para recuperar su contraseña</h1>"; 
			//para el envío en formato HTML 
			$headers = "MIME-Version: 1.0\r\n"; 
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
			//dirección del remitente 
			$headers .= "From: JPStore <conoelmarginado@outlook.com>\r\n"; 
			//dirección de respuesta, si queremos que sea distinta que la del remitente 
			$headers .= "Reply-To: conoelmarginado@outlook.com\r\n"; 
			//ruta del mensaje desde origen a destino 
			$headers .= "Return-path: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibián copia 
			$headers .= "Cc: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibirán copia oculta 
			$headers .= "Bcc: conoelmarginado@outlook.com\r\n"; 
			mail($destinatario,$asunto,$cuerpo,$headers);
			echo '<script>alert("Revise su correo")</script>
			  <script>window.location="index.php"</script>';
		}else{
			echo '<script>alert("EL correo no existe en nuestra base de datos")</script>
			 	  <script>window.location="index.php"</script>';
		}
	
?>