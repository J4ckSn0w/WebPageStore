<?php
	include "db.php";
	$correo = $_GET['correo'];
	$cliente = $_GET['cliente'];
	$consulta = $conexion->query("SELECT * FROM `preguntas` P,`respuestas` R WHERE P.id_pregunta = R.id_pregunta_fk  and R.id_user_fk = '$cliente' ");
	$respuestas = $consulta->fetch_array();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pregunta de Recuperación</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Sublime project">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/styles/bootstrap4/bootstrap.min.css">
	<link href="/plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="/styles/contact.css">
	<link rel="stylesheet" type="text/css" href="/styles/contact_responsive.css">
</head>
<body>
	<div class="super_container">

	<!-- Header -->
	<header class="header">
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo"><a href="#">JPStore</a></div>
							<nav class="main_nav">
								<ul>
									<li>
										<a href="/index.php">Home</a>
									</li>
						
									<li><a href="/contact.html">Contactanos</a></li>
								</ul>
							</nav>
							
								<!--<div class="hamburger"><i class="fa fa-bars" aria-hidden="true"></i></div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Search Panel -->
		<div class="search_panel trans_300">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="search_panel_content d-flex flex-row align-items-center justify-content-end">
							<form action="#">
								<input type="text" class="search_input" placeholder="Search" required="required">
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Social -->
		<div class="header_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</header>
	<br>
	<br>
	<div class="contact">
		<div class="container">
			<div class="row">
				<!-- Get in touch -->
				<div class="col-lg-8 contact_col">
					<div class="get_in_touch">
						<div class="section_title">Responde como respondiste cuando te registraste </div>
						<div class="section_subtitle"><?php echo $respuestas['pregunta']; ?></div>
						<div class="contact_form_container">
							<form  action="recuperar-pass-send.php?correo=<?php echo $correo; ?>&cliente=<?php echo $cliente; ?>" method="post" id="contact_form" class="contact_form">
								<div class="row">
									<div class="col-xl-6">
										<!-- Name -->
										<label for="contact_name">Respuesta</label>
										<input type="text" class="contact_input" name="respuesta" placeholder="Respuesta" required="required">
									</div>
									
									<div class="col-xl-6">
										<input class="button contact_button" type="submit" value="Enviar Respuesta">
										
									</div>
	
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
	<h2></h2>
	<h3></h3>
	<!--<form method="post" action="">
		Respuesta<input type="text" name="respuesta">
		<input type="submit" value="Recuperar contraseña">
	</form> -->
	<script src="/js/jquery-3.2.1.min.js"></script>
	<script src="/styles/bootstrap4/popper.js"></script>
	<script src="/styles/bootstrap4/bootstrap.min.js"></script>
	<script src="/plugins/greensock/TweenMax.min.js"></script>
	<script src="/plugins/greensock/TimelineMax.min.js"></script>
	<script src="/plugins/scrollmagic/ScrollMagic.min.js"></script>
	<script src="/plugins/greensock/animation.gsap.min.js"></script>
	<script src="/plugins/greensock/ScrollToPlugin.min.js"></script>
	<script src="/plugins/easing/easing.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
	<script src="/js/contact.js"></script>
</body>
</html>