<?php
		$ce = $_POST['ce'];
		$destinatario = $ce; 
		$asunto = "Prueba jeje "; 
		$cuerpo = "<h1>Si sirvió :v tu correo es $ce </h1>"; 
		//para el envío en formato HTML 
		$headers = "MIME-Version: 1.0\r\n"; 
		$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
		//dirección del remitente 
		$headers .= "From: CORREO DE PRUEBA :V <conoelmarginado@outlook.com>\r\n"; 
		//dirección de respuesta, si queremos que sea distinta que la del remitente 
		$headers .= "Reply-To: conoelmarginado@outlook.com\r\n"; 
		//ruta del mensaje desde origen a destino 
		$headers .= "Return-path: conoelmarginado@outlook.com\r\n"; 
		//direcciones que recibián copia 
		$headers .= "Cc: conoelmarginado@outlook.com\r\n"; 
		//direcciones que recibirán copia oculta 
		$headers .= "Bcc: conoelmarginado@outlook.com\r\n"; 
		mail($destinatario,$asunto,$cuerpo,$headers);
		echo '<script>alert("Mensaje enviado a '.$ce.'")</script>
			  <script>window.location="index.php"</script>';
?>