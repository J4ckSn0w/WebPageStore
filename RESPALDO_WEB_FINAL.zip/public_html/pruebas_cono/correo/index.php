<!DOCTYPE html>
<html>
<head>
	<title>Prueba de correo</title>
</head>
<body>
	<form method="post" action="correo.php" >
		<input type="email" name="ce">
		<input type="submit" value="Enviar">
	</form>
</body>
</html>