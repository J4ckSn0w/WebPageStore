<!DOCTYPE html>
<html>
<head >
	<title>LOGIN CHAT</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link href="https://fonts.googleapis.com/css?family=Mukta+Vaani" rel="stylesheet">
	<script type="text/javascript">
		function login(){
			var user = document.getElementById("user").value;
			var pass = document.getElementById("pass").value;
			window.location.href = "login.php?user="+user+"&pass="+pass;
		}
	</script>
</head>
<body>
	<div id="contenedor">
		<div id="caja-chat">
			
				<span style="color: #f90655;">Ingresar al chat con el Admin </span>
				<input type="text" name="user" id="user" placeholder="Usuario"><br>
				<input type="password" name="pass" id="pass" placeholder="Password"><br>
				<button id="btn" onclick="login()">Ingresar</button>
			
		</div>
	</div>
	</script>
</body>
</html>
