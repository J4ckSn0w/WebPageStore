<?php
	include "db.php";
	$correo = $_GET['correo'];
	$cliente = $_GET['cliente'];
	$consulta = $conexion->query("SELECT * FROM `preguntas` P,`respuestas` R WHERE P.id_pregunta = R.id_pregunta_fk  and R.id_user_fk = '$cliente' ");
	$respuestas = $consulta->fetch_array();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Pregunta de Recuperación</title>
</head>
<body>
	<h2>Responde como respondiste cuando te registraste</h2>
	<h3><?php echo $respuestas['pregunta']; ?></h3>
	<form method="post" action="recuperar-pass-send.php?correo=<?php echo $correo; ?>&cliente=<?php echo $cliente; ?>">
		Respuesta<input type="text" name="respuesta">
		<input type="submit" value="Recuperar contraseña">
	</form>
</body>
</html>