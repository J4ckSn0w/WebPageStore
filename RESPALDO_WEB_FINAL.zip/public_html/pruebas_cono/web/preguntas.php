<?php

	function repetidos($num,$vec){
		for($j = 0; $j < 3; $j++){
			if($num == $vec[$j])
				return 1;
		}
		return 0;
	}
	include "db.php";
	$array = array(0,0,0);
	$array2 = array('','','');
	$num = 0;
	for($i=0; $i < 3; $i++){
		do{
			$num = rand(1,7);
		}while(repetidos($num,$array,$i) == 1); 
		$array[$i] = $num;
		$consulta = $conexion->query("SELECT * FROM `preguntas` WHERE `id_pregunta` = '$num' ");
		$f = $consulta->fetch_array();
		$array2[$i] = $f['pregunta'];
	}

?>	
	<select>
		<option value="<?php echo $array[0]; ?>"> <?php echo $array2[0]; ?> </option>
		<option value="<?php echo $array[1]; ?>"> <?php echo $array2[1]; ?> </option>
		<option value="<?php echo $array[2]; ?>"> <?php echo $array2[2]; ?> </option>
	</select>
	<input type="text" name="resp" placeholder="Respuesta">