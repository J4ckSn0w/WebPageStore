<?php
		
?>	
<!DOCTYPE html>
<html>
<head>
	<title>Recuperar Password</title>
</head>
<body>
	<form method="post" action="mandar_msj_recuperacion.php">
		Ingresa tu correo <input type="email" name="email"> <br>
		<input type="submit" value="Enviar">		
	</form>
</body>
</html>