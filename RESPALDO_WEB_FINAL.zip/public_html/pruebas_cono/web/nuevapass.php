<?php
	include "db.php";
	$pass1 = md5($_POST['pass1']);
	$pass2 = md5($_POST['pass2']);
	$correo = $_GET['correo'];
	$cliente = $_GET['cliente'];
	if(strcmp($pass1, $pass2) == 0){
		$consulta = $conexion->query("UPDATE `clientes` SET `password`= '$pass1'  WHERE `id` = '$cliente'");
		echo '<script>alert("Contraseña cambiada")</script>
			  <script>window.location="/index.php"</script>';
	}else{
		echo '<script>alert("Las contraseñas no coinciden")</script>
			  <script>window.location="preguntas_msj.php?correo='.$correo.'&cliente='.$cliente.'"</script>';
	}
?>