<?php
	include "db.php";
	$respuesta = $_POST['respuesta'];
	$correo  = $_GET['correo'];
	$cliente = $_GET['cliente'];
	$consulta = $conexion->query("SELECT * FROM `respuestas` WHERE `id_user_fk` = '$cliente'");
	$res = $consulta->fetch_array();
    $respuesta = strtoupper($respuesta);
    $respuesta2 = strtoupper($res['respuesta']);
    if(strcmp($respuesta, $respuesta2) == 0){
    ?>
    	<!DOCTYPE html>
    	<html>
    	<head>
    		<title>Nueva Contraseña</title>
    	</head>
    	<body>
    	   <form method="post" action="nuevapass.php?correo=<?php echo $correo; ?>&cliente=<?php echo $cliente; ?>" >
    			<h1>Escribe tu nueva contraseña</h1>
    			Contraseña<input type="password" name="pass1" ><br>
    			Repite    <input type="password" name="pass2" ><br>
    			<input type="submit" value="Cambiar contraseña">
    		</form>
    	</body>
    	</html>
   	<?php
    }else{
    	echo '<script>alert("No es la repuesta")</script>
			  <script>window.location="preguntas_msj.php?correo='.$correo.'&cliente='.$cliente.'"</script>';
    }
?>