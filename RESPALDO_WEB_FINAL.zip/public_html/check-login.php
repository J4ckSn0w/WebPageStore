<?php
	session_start();
	include "db.php";
	$correo = $_POST['email'];
	$pass  = md5($_POST['password']);
	if($correo == "admin@gmail.com" && $pass == md5("admin") ){ //admin
		$_SESSION['name'] = "Admin";
		$_SESSION['loggedin'] = true;
		$_SESSION['start'] = time();
	 	header("Location: opciones.php");
	}else{ //Usuario normal
		$consulta = $conexion->query("SELECT * FROM `clientes` WHERE `email` = '$correo' and `password` = '$pass'");
		if($res = $consulta->fetch_array()){ //existe el usuario y contraseña
			$intentos = $res['intentos'];
			if($intentos > 0){ //Tiene sus intentos mayor a 0
				$id = $res['id'];
				$consulta2 = $conexion->query("UPDATE `clientes` SET `intentos` = '3' WHERE `id` = '$id'");
				$_SESSION['sessClientesID'] = $res['id'];
				$_SESSION['loggedin'] = true;
				$_SESSION['name'] = $res['name'];
				$_SESSION['start'] = time();
				$_SESSION['expire'] = $_SESSION['start'] + (1 * 60) ;
				if(!empty($_POST["remember"])){
					setcookie("emails",$email,time()+3600);
					header("location:checkout.php");
					//despues de aqui lo podemos mandar a donde queramos
					}
					else{
					if(isset($_COOKIE["emails"]))   
					    {  
					     setcookie("emails","");  
					    }  
					    header("location:checkout.php");
				    }  		
			}else{
				echo '<script>alert("Se ha bloqueado tu cuenta, entra a Olvidaste la contraseña para recuperarla")</script>
				    <script>window.location="login.php"</script>';
			}
		}else{ //la contraseña fue invalida
			$consulta3 = $conexion->query("SELECT * FROM `clientes` WHERE `email` = '$correo' ");
			if($res2 = $consulta3->fetch_array()){ //Existe el cliente
				$id = $res2['id'];
				$intentos = $res2['intentos'];
				if($intentos > 0){
					$intentos--;
					$consulta4 = $conexion->query("UPDATE `clientes` SET `intentos` = '$intentos' WHERE `id` = '$id'");
					echo '<script>alert("Contraseña incorrecta")</script> <script>window.location="login.php"</script>';
				}else{
					echo '<script>alert("Se ha bloqueado tu cuenta, entra a Olvidaste la contraseña para recuperarla")</script>
				    <script>window.location="login.php"</script>';
				}
			
			}else{ //No existe
				echo '<script>alert("El correo no existe en nuestra base de datos")</script>
				    <script>window.location="login.php"</script>';
			}
		}
	}


?>

<!--<!doctype html>
<html lang="en">
  <head>
    <title>Crear sesion</title>
	
    <!-- Required meta tags --
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS --
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
  </head>
  
  <body>  
  <div class="container">
  
<?php
	
	/*if(!isset($_POST['login'])){

		header("location:login.php");
	}
	else{
	include 'db.php';
	$email = $_POST['email']; 
	$password = $_POST['password'];
	
	$query = $conexion->query("SELECT id,email, password,name FROM clientes WHERE email = '$email'");
	$custRow = $query->fetch_assoc();

	 if($custRow['email']=="user@gmail.com"){
	 	header("location:maximo.php");
	 }

	// Variable $hash hold the password hash on database
	$hash = $custRow['password'];
	
	/* 
	
	el password ya esta encriptado y checa que este bien
	
	if (password_verify($_POST['password'], $hash)) {	
		
		$_SESSION['sessClientesID'] = $custRow['id'];
		$_SESSION['loggedin'] = true;
		$_SESSION['name'] = $row['Name'];
		$_SESSION['start'] = time();
		$_SESSION['expire'] = $_SESSION['start'] + (1 * 60) ;						
		
		if(!empty($_POST["remember"])){
		setcookie("emails",$email,time()+3600);
		
		header("location:checkout.php");
		//despues de aqui lo podemos mandar a donde queramos
		}
		else{
		if(isset($_COOKIE["emails"]))   
		    {  
		     setcookie("emails","");  
		    }  
		    header("location:checkout.php");
	    }  
		
	   
	
	} 
	else {
		echo "<div class='alert alert-danger' role='alert'>Email or Password are incorrects!
		<p><a href='login.php'><strong>Please try again!</strong></a></p></div>";			
		}
  */
	//}
		
?>
</div>

	<!-- Optional JavaScript --
    <!-- jQuery first, then Popper.js, then Bootstrap JS --
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>

	</body>
</html> -->