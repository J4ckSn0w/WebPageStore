<?php
$dbhost = "localhost";
$dbUser= "root";
$dbPassword = "";
$dbName = "id8066023_juanpistore";
$db = new mysqli($dbhost, $dbUser, $dbPassword, $dbName);

$db=new mysqli($dbhost,$dbUser,$dbPassword,$dbName);

if($db->connect_error){
	die("No se puede conectar mi chavo".$db->connect_error);
}
