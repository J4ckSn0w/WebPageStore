<?php 
 

include 'pruebas_cono/chat_ajax/db.php';
include 'Carro.php';

$carro=new Carro;

//si el carro esta vacio redireccionar
if($carro->total_items() <= 0){
    header("Location: index.php" );
}
//aqui es para enviar a si esta ya iniciada la sesion
if (isset($_SESSION['sessClientesID']))
    {  
    } else {
        echo "<div class='alert alert-danger' role='alert'>
        <h4>Tienes que logearte para poder comprar.</h4>
        <p><a href='login.php'>Registrate aqui</a></p></div>";
        exit;
    }
$query = $conexion->query("SELECT * FROM clientes WHERE id = ".$_SESSION['sessClientesID']);
$custRow = $query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Checkout</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sublime project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/checkout.css">
<link rel="stylesheet" type="text/css" href="styles/checkout_responsive.css">
<link rel="stylesheet" type="text/css" href="styles/cart.css">
<link rel="stylesheet" type="text/css" href="styles/cart_responsive.css">
<script >


      var precio;
        var descuento;
        var total;
        x = new Boolean(false);
        y= new Boolean(false);
         var paises=["Mexico","Estados Unidos"];
        var provincias_1=new Array("-","Aguascalientes","Mexico","San Luis Potosi","Puebla","Guanajuato","Leon,Gto","...")
        var provincias_2=new Array("-","California","Los Angeles","San Diego","Chicago","San Antonio","...")
        var pais
        var impuesto


        function completo(f){
            if(y==false){

                alert("Selecciono metodo de envio");
                return false;
            }
            else{
                //location.href ="AccionCarro.php?action=placeOrder";
                alert("Sera envio exitoso");
                return true;
                 

            }
        }


    function envio(){


    if(document.getElementById("tipo2").checked){
        precio= parseInt(document.getElementById("tipo2").value);
      descuento="Entrega Premium"
    }
    else if(document.getElementById("tipo").checked){
        precio= parseInt(document.getElementById("tipo").value);
      descuento="Entrega Standart"
      }
      else{
        precio= 0;
      descuento="Gratuito"
      }

      
      document.getElementById("precio").innerHTML=precio;
      document.getElementById("precio2").innerHTML=precio;
      total='<?php echo $carro->total()?>';
      total=parseInt(total)+parseInt(precio);
      document.getElementById("total").innerHTML=total;
      document.getElementById("total1").innerHTML=total;
      document.getElementById("nombre3").value=descuento+"    "+precio;
     
        y=true;

     }
     function cupon(){// es para el funcinamiento de la cuponera x es una variable booleana sobre si ya se aplico un decuento o no
        var cupones = document.getElementById("cuponera").value;
        
        if(x==true){
            alert("Ya se aplico tu descuento");
        }
        else if(cupones=="navidad2018" && x == false){
            total=(total*.90);
             
            x=true;
            alert("Se ha aplicado un cupon con 10%");
        }
         else if(cupones=="cono" && x==false){
            total=(total*.90);
            x=true;
            
            alert("Se ha aplicado un cupon con 10%");
        }
        else if(cupones=="fuantitis" && x==false){
            total=(total*.90);
            x=true;
            alert("Se ha aplicado un cupon con el 10%");
        }else{
            alert("No existe ese codigo")
          document.getElementById("total").innerHTML=total;
          document.getElementById("total1").innerHTML=total;
          document.getElementById("nombre6").value="-";
          document.getElementById("descuentos").innerHTML="-";// lo manda al span id descuentos
           document.getElementById("descuentos1").innerHTML="-";// lo manda al span id descuentos
           return;
        }
          document.getElementById("total").innerHTML=total;
          document.getElementById("total1").innerHTML=total;
          document.getElementById("nombre5").value=total;
          document.getElementById("nombre6").value=total*.10;
          document.getElementById("descuentos").innerHTML=total*.10;// lo manda al span id descuentos
           document.getElementById("descuentos1").innerHTML=total*.10;// lo manda al span id descuentos

     }
    

//función que cambia las provincias del select de provincias en función del país que se haya escogido en el select de país.
function cambia_provincia(){
    //tomo el valor del select del pais elegido
    
    pais = document.f1.pais[document.f1.pais.selectedIndex].value
    //miro a ver si el pais está definido
    if (pais != 0) {
        //si estaba definido, entonces coloco las opciones de la provincia correspondiente.
        //selecciono el array de provincia adecuado
        mis_provincias=eval("provincias_" + pais)
        //calculo el numero de provincias
        num_provincias = mis_provincias.length
        //marco el número de provincias en el select
        document.f1.provincia.length = num_provincias
        //para cada provincia del array, la introduzco en el select
        for(i=0;i<num_provincias;i++){
           document.f1.provincia.options[i].value=mis_provincias[i]
           document.f1.provincia.options[i].text=mis_provincias[i]
        }   
    }else{
        //si no había provincia seleccionada, elimino las provincias del select
        document.f1.provincia.length = 1
        //coloco un guión en la única opción que he dejado
        document.f1.provincia.options[0].value = "-"
        document.f1.provincia.options[0].text = "-"
    }
    //marco como seleccionada la opción primera de provincia
    document.f1.provincia.options[0].selected = true
    
   
}
 function Impuestos(){
    var provincia;
    var mensaje;
    provincia = document.f1.provincia[document.f1.provincia.selectedIndex].value

     if(total==0){
        alert("Deben de elegir metodo de Envio");
        return false;
     }
     if(paises[pais-1]=="Estados Unidos"){
        total=total*1.15;
        impuesto=total*.15;
        mensaje="Se aplico un impuesto de envio al ser Estados Unidos del 15%      "
     }else{
        mensaje="No se considera ningun impuesto al ser envios Nacionales      "
     }
     document.getElementById("nombre1").value =paises[pais-1];
     document.getElementById("nombre2").value=provincia;
     document.getElementById("nombre4").value =mensaje+impuesto;
     document.getElementById("nombre5").value=total;
     document.getElementById("total").innerHTML=total;
      document.getElementById("total1").innerHTML=total;
     document.getElementById("impuestos1").innerHTML=impuesto;
     return true;
     
 }

</script>
</head>
<body>

<div class="super_container">

    <!-- Header -->

    <header class="header">
        <div class="header_container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="header_content d-flex flex-row align-items-center justify-content-start">
                            <div class="logo"><a href="#">Sublime.</a></div>
                            <nav class="main_nav">
                                <ul>
                                    <li class="hassubs active">
                                        <a href="index.html">Home</a>
                                        <ul>
                                    <li class="hassubs active">
                                        <a href="index.php">Home</a>
                                        <ul>
                                            <li><a href="categories.php">Categorias</a></li>
                                            <li><a href="product.html">Product</a></li>
                                            <li><a href="verCarrito.php">Carro</a></li>
                                            <li><a href="checkout.php">Check out</a></li>
                                            <li><a href="contact.html">Contactanos</a></li>
                                        </ul>
                                    </li>
                                    <li class="hassubs">
                                        <a href="categories.php">Categorias</a>
                                        <ul>
                                            <li><a href="categories.php">Categoria</a></li>
                                             <li><a href="categoria_cel.php">Smarthphones</a></li>
                                            <li><a href="categoria_tv.php">Televisiones</a></li>
                                            <li><a href="categoria_compu.php">Computadoras</a></li>
                                            <li><a href="categoria_cam.html">Camara</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Accesorios</a></li>
                                    <li><a href="#">Ofertas</a></li>
                                    <li><a href="contact.html">Contactanos</a></li>
                                </ul>
                            </nav>
                            <div class="header_extra ml-auto">
                                <div class="shopping_cart">
                                    <a href="cart.html">
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                 viewBox="0 0 489 489" style="enable-background:new 0 0 489 489;" xml:space="preserve">
                                            <g>
                                                <path d="M440.1,422.7l-28-315.3c-0.6-7-6.5-12.3-13.4-12.3h-57.6C340.3,42.5,297.3,0,244.5,0s-95.8,42.5-96.6,95.1H90.3
                                                    c-7,0-12.8,5.3-13.4,12.3l-28,315.3c0,0.4-0.1,0.8-0.1,1.2c0,35.9,32.9,65.1,73.4,65.1h244.6c40.5,0,73.4-29.2,73.4-65.1
                                                    C440.2,423.5,440.2,423.1,440.1,422.7z M244.5,27c37.9,0,68.8,30.4,69.6,68.1H174.9C175.7,57.4,206.6,27,244.5,27z M366.8,462
                                                    H122.2c-25.4,0-46-16.8-46.4-37.5l26.8-302.3h45.2v41c0,7.5,6,13.5,13.5,13.5s13.5-6,13.5-13.5v-41h139.3v41
                                                    c0,7.5,6,13.5,13.5,13.5s13.5-6,13.5-13.5v-41h45.2l26.9,302.3C412.8,445.2,392.1,462,366.8,462z"/>
                                            </g>
                                        </svg>
                                        <div>Carro <span><?php echo '('.$carro->total_items().')';?></span></div>
                                    </a>
                                </div>
                                <div class="search">
                                    <div class="search_icon">
                                        <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                        viewBox="0 0 475.084 475.084" style="enable-background:new 0 0 475.084 475.084;"
                                         xml:space="preserve">
                                        <g>
                                            <path d="M464.524,412.846l-97.929-97.925c23.6-34.068,35.406-72.047,35.406-113.917c0-27.218-5.284-53.249-15.852-78.087
                                                c-10.561-24.842-24.838-46.254-42.825-64.241c-17.987-17.987-39.396-32.264-64.233-42.826
                                                C254.246,5.285,228.217,0.003,200.999,0.003c-27.216,0-53.247,5.282-78.085,15.847C98.072,26.412,76.66,40.689,58.673,58.676
                                                c-17.989,17.987-32.264,39.403-42.827,64.241C5.282,147.758,0,173.786,0,201.004c0,27.216,5.282,53.238,15.846,78.083
                                                c10.562,24.838,24.838,46.247,42.827,64.234c17.987,17.993,39.403,32.264,64.241,42.832c24.841,10.563,50.869,15.844,78.085,15.844
                                                c41.879,0,79.852-11.807,113.922-35.405l97.929,97.641c6.852,7.231,15.406,10.849,25.693,10.849
                                                c9.897,0,18.467-3.617,25.694-10.849c7.23-7.23,10.848-15.796,10.848-25.693C475.088,428.458,471.567,419.889,464.524,412.846z
                                                 M291.363,291.358c-25.029,25.033-55.148,37.549-90.364,37.549c-35.21,0-65.329-12.519-90.36-37.549
                                                c-25.031-25.029-37.546-55.144-37.546-90.36c0-35.21,12.518-65.334,37.546-90.36c25.026-25.032,55.15-37.546,90.36-37.546
                                                c35.212,0,65.331,12.519,90.364,37.546c25.033,25.026,37.548,55.15,37.548,90.36C328.911,236.214,316.392,266.329,291.363,291.358z
                                                "/>
                                        </g>
                                    </svg>
                                    </div>
                                </div>
                                <div class="hamburger"><i class="fa fa-bars" aria-hidden="true"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Search Panel -->
        <div class="search_panel trans_300">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="search_panel_content d-flex flex-row align-items-center justify-content-end">
                            <form action="#">
                                <input type="text" class="search_input" placeholder="Search" required="required">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Social -->
        <div class="header_social">
            <ul>
                <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            </ul>
        </div>
    </header>

    <!-- Menu -->

    <div class="menu menu_mm trans_300">
        <div class="menu_container menu_mm">
            <div class="page_menu_content">
                            
                <div class="page_menu_search menu_mm">
                    <form action="#">
                        <input type="search" required="required" class="page_menu_search_input menu_mm" placeholder="Search for products...">
                    </form>
                </div>
                <ul class="page_menu_nav menu_mm">
                    <li class="page_menu_item has-children menu_mm">
                        <a href="index.html">Home<i class="fa fa-angle-down"></i></a>
                        <ul class="page_menu_selection menu_mm">
                            <li class="page_menu_item menu_mm"><a href="categories.html">Categories<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="product.html">Product<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="verCarrito.php">Cart<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="checkout.html">Checkout<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
                        </ul>
                    </li>
                    <li class="page_menu_item has-children menu_mm">
                        <a href="categories.php">Categorias<i class="fa fa-angle-down"></i></a>
                        <ul class="page_menu_selection menu_mm">
                            <li class="page_menu_item menu_mm"><a href="categoria_cel.php">Smart Phones<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="categoria_tv.php">Televisiones<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="categoria_compu.php">Computadoras<i class="fa fa-angle-down"></i></a></li>
                            <li class="page_menu_item menu_mm"><a href="categoria_cam.php">Cámaras<i class="fa fa-angle-down"></i></a></li>
                        </ul>
                    </li>
                    <li class="page_menu_item menu_mm"><a href="index.html">Accessories<i class="fa fa-angle-down"></i></a></li>
                    <li class="page_menu_item menu_mm"><a href="#">Offers<i class="fa fa-angle-down"></i></a></li>
                    <li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
                </ul>
            </div>
        </div>

        <div class="menu_close"><i class="fa fa-times" aria-hidden="true"></i></div>

        <div class="menu_social">
            <ul>
                <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            </ul>
        </div>
    </div>
    
    <!-- Home -->

    <div class="home">
        <div class="home_container">
            <div class="home_background" style="background-image:url(images/cart.jpg)"></div>
            <div class="home_content_container">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <div class="home_content">
                                <div class="breadcrumbs">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="verCarrito.php">Carrito</a></li>
                                        <li>Checkout</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Checkout -->
    
    <div class="checkout">
        <div class="container">
            <div class="row">

                <!-- Billing Info -->
                <div class="col-lg-6">
                    <div class="billing checkout_section">
                        <div class="section_title">Tarjeta de Compra</div>
                        <div class="section_subtitle">Ingresa el destino de la Compra</div>
                        <div class="checkout_form_container">
                            <form  action=" orderSuccess.php" method="post"  onsubmit="return completo(this)">
                                <div >
                                   
                                        <!-- Name -->
                                        <label for="checkout_name">Nombre*</label>
                                        <input type="text" id="checkout_name" class="checkout_input" required="required" value="<?php echo $custRow['name']; ?>" name="name">
  
                                </div>
                                
                                <div>
                                    <!-- Address -->
                                    <label for="checkout_address">Direccion*</label>
                                    <input type="text" id="checkout_address" class="checkout_input" required value="<?php echo $custRow['address']; ?>" name="direccion">
                                    <input type="text" id="checkout_address_2" class="checkout_input checkout_address_2" required>
                                </div>
                                <div>
                                    <!-- Zipcode -->
                                    <label for="checkout_zipcode">Codigo Postal*</label>
                                    <input type="text" id="checkout_zipcode" class="checkout_input" required>
                                </div>
                                <div>
                                    <!-- Province -->
                                </div>
                                <div>
                                    <!-- Phone no -->
                                    <label for="checkout_phone">Numero de telefono*</label>
                                    <input type="phone" id="checkout_phone" class="checkout_input" name="numerotel" required>
                                </div>
                                <div>
                                    <!-- Email -->
                                    <label for="checkout_email">Direccion de Email*</label>
                                    <input type="phone" id="checkout_email" class="checkout_input" required value="<?php echo $custRow['email']; ?>" name="email">
                                </div>
                                <div class="checkout_extra">
                                    <div>
                                        <input type="checkbox" id="checkbox_terms" name="regular_checkbox" class="regular_checkbox" checked="checked">
                                        <label for="checkbox_terms"><img src="images/check.png" alt=""></label>
                                        <span class="checkbox_title">Terminos y Condiciones</span>
                                    </div>
                                    
                                    <div>
                                        <input type="checkbox" id="checkbox_newsletter" name="regular_checkbox" class="regular_checkbox">
                                        <label for="checkbox_newsletter"><img src="images/check.png" alt=""></label>
                                        <span class="checkbox_title">Subscribite a nuestra Gaceta</span>
                                        <input type="hidden"  id="nombre1" name="nombre1" value="" required>
                                        <input type="hidden"  id="nombre2" name="nombre2" value="" required >
                                        <input type="hidden"  id="nombre3" name="nombre2" value="" required>
                                        <input type="hidden"  id="nombre4" name="nombre1" value="" required>
                                        <input type="hidden"  id="nombre5" name="nombre2" value="" required>
                                        <input type="hidden"  id="nombre6" name="nombre2" value="1" required>
                                        <input type="hidden" name="action" id=action value=placeOrder>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <br>
                                <button type="submit" class="btn btn-success orderBtn" >Comprar</button>
                                
                               
                               Realizar la orden <i class="glyphicon glyphicon-menu-right"></i></a>
                            </form>
                             <div>
                                    <!-- Country -->
                                    <label for="checkout_country">Pais*</label>
                                    <form name="f1">
                                    <select name=pais onchange="cambia_provincia()">
                                    <option value="0" selected>Seleccione...
                                    <option value="1" >Mexico
                                    <option value="2">Estados Unidos
                                    </select>

                                    <select name=provincia onchange="return Impuestos()" >
                                    <option value="-">-
                                    </select>
                                      
                                </form>
                                  
                                </div>


                        </div>
                    </div>
                </div>

                <!-- Order Info -->

                <div class="col-lg-6">
                    <div class="order checkout_section">
                        <div class="section_title">Tu orden</div>
                        <div class="section_subtitle">Detalles de Orden</div>

                        <!-- Order details -->
                       <table class="table">
                            <thead>
                                <tr>
                                    <th class="order_list_title">Producto</th>
                                    <th class="order_list_title">Precio</th>
                                    <th class="order_list_title">Cantidad</th>
                                    <th class="order_list_title">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                               
                                if($carro->total_items() > 0){
                                    //get cart items from session
                                    $cartItems = $carro->contenido();
                                    foreach($cartItems as $item){
                                ?>
                                <tr>
                                    <td class="order_list_title"><?php echo $item["name"]; ?></td>
                                    <td class="order_list_title"><?php echo '$'.$item["price"].' pesos'; ?></td>
                                    <td class="order_list_title"><?php echo $item["qty"]; ?></td>
                                    <td class="order_list_title"><?php echo '$'.$item["subtotal"].' pesos'; ?></td>
                                </tr>
                                <?php } }else{ ?>
                                <tr><td colspan="4"><p>Esta vacio.....</p></td>
                                <?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3"></td>
                                    <?php if($carro->total_items() > 0){ ?>
                                    <td class="text-center"><strong>Total <?php echo '$'.$carro->total().' pesos ';?></strong></td>
                                    <?php } ?>
                                </tr>
                            </tfoot>
                            </table>

                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="order_list_title">Envio</div>
                                    <div class="order_list_value ml-auto"><span id="precio2"></span>
                                      
                                    </div>
                                </li>

                                 <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="order_list_title">Impuestos</div>
                                    <div class="order_list_value ml-auto"><span id="impuestos1">-</span>
                                      
                                    </div>
                                </li>

                                 <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="order_list_title">Descuentos</div>
                                    <div class="order_list_value ml-auto"><span id="descuentos1">-</span>
                                      
                                    </div>
                                </li>

                                  <li class="d-flex flex-row align-items-center justify-content-start">
                                    <?php if($carro->total_items() > 0){ ?>
                                         <div class="order_list_title">Total</div>
                                        <div class="order_list_value ml-auto"><span id="total1">-</span></div>
                                </li>
                                    <?php } ?>

                            </ul>
                        </div>

                        <!-- Payment Options -->
                        <div class="payment">
                            <div class="payment_options">
                                <label class="payment_option clearfix">Paypal
                                    <input type="radio" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="payment_option clearfix">Pago en Efectivo
                                    <input type="radio" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="payment_option clearfix">Tarjeta de Credito
                                    <input type="radio" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                                <label class="payment_option clearfix">Transferencia de Pago Interbancario
                                    <input type="radio" checked="checked" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>
                        
                        <!-- Order Text -->
                        <div class="order_text">La compra sera valida en los primeros 30 dias </div>
                        <div class="button order_button"><a href="#">Realizar Compra</a></div>
                    </div>
                </div>

            </div>
        </div>        
    </div>

    <div class="row cart_items_row">
                <div class="col">       
            <div class="row row_extra">
                <div class="col-lg-5 offset-lg-1">
                    
                    <!-- Delivery -->
                    <div class="delivery">
                        <div class="section_title">Metodo de envio</div>
                        <div class="section_subtitle">Selecciona el que deseas</div>
                        <form>
                        <div class="delivery_options">
                            <label class="delivery_option clearfix">Entrega Premium
                                <input type="radio" name="radio" id="tipo" value="500" required>
                                <span class="checkmark"></span>
                                <span class="delivery_price">$500</span>
                            </label>
                            <label class="delivery_option clearfix">Entrega Standart
                                <input type="radio" name="radio" id="tipo2" value="200" required>
                                <span class="checkmark"></span>
                                <span class="delivery_price">$200</span>
                            </label>
                            <label class="delivery_option clearfix">Entrega Gratuita
                                <input type="radio" checked="checked" name="radio" id="tipo3" value="0" required>
                                <span class="checkmark"></span>
                                <span class="delivery_price">Gratuito</span>
                            </label>
                            
                                
                        </div>
                        <button  type="button" class="button coupon_button" onClick='envio()'>Envio</button>
                    </form>
                    </div>

                    <!-- Coupon Code -->
                    <div class="coupon">
                        <div class="section_title">Cupon</div>
                        <div class="section_subtitle">Ingresa un codigo de cupon</div>
                        <div class="coupon_form_container">
                            <form action="#" id="coupon_form" class="coupon_form">
                                <input type="text" class="coupon_input" id="cuponera" required="required">
                                <button class="button coupon_button" type="button" onClick='cupon()'><span>Aplicar</span></button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 offset-lg-1">
                    <div class="cart_total">
                        <div class="section_title">Venta Total</div>
                        <div class="section_subtitle">Informacion Final</div>
                        <div class="cart_total_container">
                            <ul>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="cart_total_title">Subtotal</div>
                                    <div class="cart_total_value ml-auto"> <?php echo '$'.$carro->total().' pesos ';?></div>
                                </li>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="cart_total_title"> Envio</div>
                                    <div class="cart_total_value ml-auto"> <span id="precio"></span></div>
                                </li>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="cart_total_title"> Descuentos</div>
                                    <div class="cart_total_value ml-auto"> <span id="descuentos">-</span></div>
                                </li>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div class="cart_total_title">Total</div>
                                    <div class="cart_total_value ml-auto"><span id="total"></span></div>
                                </li>
                            </ul>
                        </div>
                        <button   type="button" onClick='completo()'><span>Compre ya</span></button>
                        
                    </div>
                </div>
            </div>
        </div>      
    </div>


            
    <!-- Footer -->
    
    <div class="footer_overlay"></div>
    <footer class="footer">
        <div class="footer_background" style="background-image:url(images/footer.jpg)"></div>
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="footer_content d-flex flex-lg-row flex-column align-items-center justify-content-lg-start justify-content-center">
                        <div class="footer_logo"><a href="#">Sublime.</a></div>
                        <div class="copyright ml-auto mr-auto"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
                        <div class="footer_social ml-lg-auto">
                            <ul>
                                <li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/checkout.js"></script>


</body>
</html>

