<?php
	//Base de datos
            //$dbHost = 'localhost';
            //$dbUsername = 'root';
            //$dbPassword = '';
            //$dbName = 'bd_web';

            //Conexión
            //$db = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
            //Checar conexión
            //if(!$db)
            //{
             //   die("Connection failed: " . //mysqli_connect_error());
            //}
            
            include 'pruebas_cono/chat_ajax/db.php';
            
            //Comando para checar que el producto no este en la BD
            $checkProd= "SELECT * FROM productos WHERE name = '$_POST[name]' ";

            //Insertar como comando
            $result = $conexion->query($checkProd);

            //Se crea un contador que guarda el resultado de la consulta
            $count = mysqli_num_rows($result);
            
            //Checar si el contador capturo algo
            if ($count == 1)
            {
                echo "<br>"."Ya existe ese producto."."</br>";
            }else
            {
                //Datos a ingresar del producto
                $name = $_POST['name'];
                $descp = $_POST['descp'];
                $precio = $_POST['precio'];
                $categ = $_POST['categ'];
                $existencia = $_POST['existencia'];
                $image = $_POST['imagen'];

                $insert = "INSERT INTO productos (name, description, price, id_category, existencia , imagen) VALUES ('$name', '$descp', '$precio', '$categ', '$existencia', '$image')";

                if(mysqli_query($conexion, $insert))
                {
                    //alert("Producto ingresado con exito");	
                    header("location: catalogoP.php");
                }else
                {
                    //alert("Hubo un error, intente de nuevo");
                }
            }
    ?>
?>