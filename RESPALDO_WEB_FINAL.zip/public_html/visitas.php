<?php
	include "db.php";
	$ip =  $_SERVER['REMOTE_ADDR'];
	$fecha = date("Y-m-d");
	$con1 = $conexion->query("SELECT * FROM `visitas` WHERE `ip_visita` = '$ip' and `date` = '$fecha' ");
	if($f = $con1->fetch_array()){
	}else{
		$con2 = $conexion->query("INSERT INTO `visitas`( `ip_visita`, `date`) VALUES ('$ip','$fecha')");
	}
	$con3 = $conexion->query("SELECT count(*) as vistas FROM `visitas` WHERE 1");
	$vistas = $con3->fetch_array();
	echo $vistas['vistas'];
?>