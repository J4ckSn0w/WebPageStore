<!doctype html>
<html lang="en">
  <head>
    <title>Crear cuenta</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
  </head>
<body>

<div class="container">

	<?php

	include 'db.php';

	$checkEmail = "SELECT * FROM clientes WHERE email = '$_POST[email]' ";

	
	$result = $conexion-> query($checkEmail);

	
	$count = mysqli_num_rows($result);


	
	if ($count == 1) {
	echo "<br />". "Ya exite este usuario." . "<br />";

	echo "<a href='login.php'>Colocar aqui tu contrasena</a>.";
	} else {	
	
	
	$name = $_POST['name'];
	$email = $_POST['email'];
	$pass = $_POST['password'];
	$num= $_POST['numerotel'];
	$direccion= $_POST['direccion'];
	
	$id_pregunta = $_POST['num_pregunta'];
	$respuesta = $_POST['resp'];
	

	// The password_hash() function convert the password in a hash before send it to the database
	$passmd5 = md5($pass);
	
	// Query to send Name, Email and Password hash to the database
	
	$query = "INSERT INTO `clientes`(`name`, `email`, `password`, `phone`, `address`, `created`, `modified`) VALUES ('$name', '$email', '$passmd5','$num','$direccion','".date("Y-m-d H:i:s")."', '".date("Y-m-d H:i:s")."')";

	if (mysqli_query($conexion, $query)) {
		echo "<div class='alert alert-success' role='alert'><h3>Tu cuenta ya se creo.</h3>
		<a class='btn btn-outline-primary' href='login.php' role='button'>Login</a></div>";		
		} else {
			echo "Error: " . $query . "<br>" . mysqli_error($conexion);
		}	
	}	
	$consulta1 = $conexion->query("SELECT * FROM `clientes` WHERE `email` = '$email'");
	$res = $consulta1->fetch_array();
	$id_user = $res['id'];
	$conrespta = $conexion->query("INSERT INTO `respuestas`(`id_pregunta_fk`, `id_user_fk`, `respuesta`) VALUES ('$id_pregunta','$id_user','$respuesta')");
	mysqli_close($conexion);
	?>
</div>


  </body>
</html>

