<?php
	//$connection = mysqli_connect('localhost' , 'root' ,'' ,'bd_web');

	include 'pruebas_cono/chat_ajax/db.php';

	$id = $_POST['id'];

	$result  = $conexion->query("DELETE FROM productos WHERE id='$id'");

	if($result){
		echo 'Informacion borrada con exito';	
	}
?>