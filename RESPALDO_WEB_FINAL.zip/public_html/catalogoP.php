<?php
    session_start();
    if(isset($_SESSION['name']) && $_SESSION['name'] == "Admin" )
    {
        $nom = $_SESSION['name'];
        //echo "<script>alert('.$nom.')</script>";
    } else 
    {
      header("Location: index.php");
    }  
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Catalogo de productos</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sublime project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/contact.css">
<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo"><a href="index.php"><img src="images/logo.jpg" height="120px"></a></div>
							
							<div class="header_extra ml-auto">
								
								<div class="search">
									<div class="search_icon">
										<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
										viewBox="0 0 475.084 475.084" style="enable-background:new 0 0 475.084 475.084;"
										 xml:space="preserve">
										<g>
											<path d="M464.524,412.846l-97.929-97.925c23.6-34.068,35.406-72.047,35.406-113.917c0-27.218-5.284-53.249-15.852-78.087
												c-10.561-24.842-24.838-46.254-42.825-64.241c-17.987-17.987-39.396-32.264-64.233-42.826
												C254.246,5.285,228.217,0.003,200.999,0.003c-27.216,0-53.247,5.282-78.085,15.847C98.072,26.412,76.66,40.689,58.673,58.676
												c-17.989,17.987-32.264,39.403-42.827,64.241C5.282,147.758,0,173.786,0,201.004c0,27.216,5.282,53.238,15.846,78.083
												c10.562,24.838,24.838,46.247,42.827,64.234c17.987,17.993,39.403,32.264,64.241,42.832c24.841,10.563,50.869,15.844,78.085,15.844
												c41.879,0,79.852-11.807,113.922-35.405l97.929,97.641c6.852,7.231,15.406,10.849,25.693,10.849
												c9.897,0,18.467-3.617,25.694-10.849c7.23-7.23,10.848-15.796,10.848-25.693C475.088,428.458,471.567,419.889,464.524,412.846z
												 M291.363,291.358c-25.029,25.033-55.148,37.549-90.364,37.549c-35.21,0-65.329-12.519-90.36-37.549
												c-25.031-25.029-37.546-55.144-37.546-90.36c0-35.21,12.518-65.334,37.546-90.36c25.026-25.032,55.15-37.546,90.36-37.546
												c35.212,0,65.331,12.519,90.364,37.546c25.033,25.026,37.548,55.15,37.548,90.36C328.911,236.214,316.392,266.329,291.363,291.358z
												"/>
										</g>
									</svg>
									</div>
								</div>
								<div class="hamburger"><i class="fa fa-bars" aria-hidden="true"></i></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Search Panel -->
		<div class="search_panel trans_300">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="search_panel_content d-flex flex-row align-items-center justify-content-end">
							<form action="#">
								<input type="text" class="search_input" placeholder="Search" required="required">
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Social -->
		<div class="header_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</header>

	<!-- Menu -->

	<div class="menu menu_mm trans_300">
		<div class="menu_container menu_mm">
			<div class="page_menu_content">
							
				<div class="page_menu_search menu_mm">
					<form action="#">
						<input type="search" required="required" class="page_menu_search_input menu_mm" placeholder="Search for products...">
					</form>
				</div>
				<ul class="page_menu_nav menu_mm">
					<li class="page_menu_item has-children menu_mm">
						<a href="index.php">Home<i class="fa fa-angle-down"></i></a>
						<ul class="page_menu_selection menu_mm">
							<li class="page_menu_item menu_mm"><a href="categories.html">Categories<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="product.html">Product<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="cart.html">Cart<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="checkout.html">Checkout<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
						</ul>
					</li>
					<li class="page_menu_item has-children menu_mm">
						<a href="categories.html">Categories<i class="fa fa-angle-down"></i></a>
						<ul class="page_menu_selection menu_mm">
							<li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
							<li class="page_menu_item menu_mm"><a href="categories.html">Category<i class="fa fa-angle-down"></i></a></li>
						</ul>
					</li>
					<li class="page_menu_item menu_mm"><a href="index.html">Accessories<i class="fa fa-angle-down"></i></a></li>
					<li class="page_menu_item menu_mm"><a href="#">Offers<i class="fa fa-angle-down"></i></a></li>
					<li class="page_menu_item menu_mm"><a href="contact.html">Contact<i class="fa fa-angle-down"></i></a></li>
				</ul>
			</div>
		</div>

		<div class="menu_close"><i class="fa fa-times" aria-hidden="true"></i></div>

		<div class="menu_social">
			<ul>
				<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			</ul>
		</div>
	</div>
	
	<!-- Home -->

	

	<!-- Contact -->
	
	<div class="contact">
		<div class="container">
			<div class="row">

				<!-- Get in touch -->
				<div class="col-lg-12 contact_col">
					<div class="get_in_touch">
						<br><br>
						<div class="section_title">Catalogo de productos</div>
						<div class="section_subtitle"> </div>
						<div class="contact_form_container">
							<!-- Productos -->
							
								<table class="table">
						           <thead>
						               <tr>
						                   <th>NOMBRE</th>
						                   <th>DESCP</th>
						                   <th>PRECIO</th>
						                   <th>CATEGORIA</th>
						                   <th>EXISTENCIA</th>
						                   <th>DIRECCION</th>
						                   <th>IMAGEN</th>
						                   <th>- - - - -</th>
						               </tr>
						           </thead>
						           <tbody>
						        <?php
						        	include 'pruebas_cono/chat_ajax/db.php';
						            //$dbHost = 'localhost';
						            //$dbUsername = 'root';
						            //$dbPassword = '';
						            //$dbName = 'bd_web';
						            
						            //$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);//Objeto que permite la conexión con mysql
						            //if($db->connect_error)
						            //{
						              //  die("Connection failed: " . $db->connect_error);
						            //}
						            $result = $conexion->query("SELECT * FROM productos ORDER BY id"); //query-> realizar consultas a la base de datos, y retorna un objeto mysqli_result
						            if ($fila = $result->fetch_array()) //Recupera fila por fila el resultado de la consulta resalizada; en la imagen el base64 es utilizado para decodificar el archivo binario que representa la imagen dentro de la base de datos (LONGBLOB)
						            {
						                do{?>
						                    <tr id="<?php echo $fila['id']; ?>">
						                        <td data-target="name"><?php echo $fila['name']; ?></td>
						                        <td data-target="descp"><?php echo $fila['description']; ?></td>
						                        <td data-target="precio"><?php echo $fila['price']; ?></td>
						                        <td data-target="categoria"><?php echo $fila['id_category']; ?></td>
						                        <td data-target="existencia"><?php echo $fila['existencia']; ?></td>
						                        <td data-target="imagen"><?php echo $fila['imagen']?></td>	
						                        <td><img src="<?php echo $fila['imagen']?>" width="100px" height="100pxs"></td>
						                        <td><a href="#" data-role="update" data-id="<?php echo $fila['id'] ;?>">Update</a></td>
						                    </tr>
						            <?php } while($fila = $result->fetch_array()); }?>
						        </tbody>
						       </table>

							<div class="col-xl-6">
								<button class="button contact_button" onclick="window.location.href='agregar.php'"><span>Agregar otro producto</span></button>
								<button class="button contact_button" onclick="window.location.href='opciones.php'"><span>Regresar al menu</span></button>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"></h4>
          </div>
          <div class="modal-body">
              <div class="form-group">
                 <label>Nombre</label>
                 <input type="text" id="name" class="form-control">
              </div>
              <div class="form-group">
                 <label>Descripcion</label>
                 <input type="text" id="descp" class="form-control">
              </div>
              <div class="form-group">
                 <label>Precio</label>
                 <input type="text" id="precio" class="form-control">
              </div>
              <div class="form-group">
                 <label>Categoria</label>
                 <input type="text" id="categoria" class="form-control">
              </div>
              <div class="form-group">
                 <label>Existencia</label>
                 <input type="text" id="existencia" class="form-control">
              </div>
              <div class="form-group">
                 <label>imagen</label>
                 <input type="text" id="imagen" class="form-control">
              </div>
              <input type="hidden" id="userId" class="form-control">
          </div>
          <div class="modal-footer">
            <a href="#" id="save" class="btn btn-primary pull-right">Update</a>
            <a href="#" id="delete" class="btn btn-primary pull-right">Delete</a>
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>

	<!-- Footer -->
	
	<div class="footer_overlay"></div>
	<footer class="footer">
		<div class="footer_background" style="background-image:url(images/footer.jpg)"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="footer_content d-flex flex-lg-row flex-column align-items-center justify-content-lg-start justify-content-center">
						<div class="footer_logo"><a href="#">Sublime.</a></div>
						<div class="copyright ml-auto mr-auto"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="footer_social ml-lg-auto">
							<ul>
								<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
<script src="js/contact.js"></script>
<script>
    $(document).ready(function(){

        $(document).on('click','a[data-role=update]', function(){
            var id = $(this).data('id');
            var name = $('#'+id).children('td[data-target=name]').text();
            var descp = $('#'+id).children('td[data-target=descp]').text();
            var precio = $('#'+id).children('td[data-target=precio]').text();
            var cat = $('#'+id).children('td[data-target=categoria]').text();
            var existencia = $('#'+id).children('td[data-target=existencia]').text();
            var imagen = $('#'+id).children('td[data-target=imagen]').text();
            
            $('#name').val(name);
            $('#descp').val(descp);
            $('#precio').val(precio);
            $('#categoria').val(cat);
            $('#existencia').val(existencia);
            $('#imagen').val(imagen);
            $('#userId').val(id);
            $('#myModal').modal('toggle');
        });                  

      $('#save').click(function(){
         var id = $('#userId').val();
         var name = $('#name').val();
         var descp = $('#descp').val();
         var precio = $('#precio').val();
         var cat = $('#categoria').val();
         var existencia = $('#existencia').val();
         var imagen = $('#imagen').val();
          
         $.ajax({
            url     : 'connection.php',
            method  : 'post',
            data    : {id : id, name : name, descp : descp, precio : precio, cat : cat, existencia : existencia, imagen : imagen},
            success : function(response){
              //console.log(response);
                    $('#'+id).children('td[data-target=name]').text(name);
                    $('#'+id).children('td[data-target=descp]').text(descp);
                    $('#'+id).children('td[data-target=precio]').text(precio);
                    $('#'+id).children('td[data-target=categoria]').text(cat);
                    $('#'+id).children('td[data-target=existencia]').text(existencia);
                    $('#'+id).children('td[data-target=imagen]').text(imagen);
                    $('#myModal').modal('toggle');
                    location.reload();	
                    } 
         }); 
      });

      $('#delete').click(function(){
         var id = $('#userId').val();
         if(confirm("Estas seguro de querer borrar el producto?")){
           $.ajax({
              url     : 'delete.php',
              method  : 'post',
              data    : {id : id},  
              success : function(response){
                //console.log(response);
                      //
                      alert(response);  
                      $('#myModal').modal('toggle');
                      location.reload();
                      } 
           }); 
         }
      });

});
</script>
</body>
</html>











