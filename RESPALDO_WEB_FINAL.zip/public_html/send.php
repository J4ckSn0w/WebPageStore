<?php
		include "db.php";
		$nombre = $_POST['nombre'];
		$apellido = $_POST['apellido'];
		$opinion = $_POST['mensaje'];
		echo $nombre;
		echo $apellido;
		echo $opinion;
			$destinatario = "conoelmarginado@outlook.com"; 
			$asunto = "Contacto de Usuario "; 
			$cuerpo = $opinion;
			//para el envío en formato HTML 
			$headers = "MIME-Version: 1.0\r\n"; 
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
			//dirección del remitente 
			$headers .= "From: JPStore <conoelmarginado@outlook.com>\r\n"; 
			//dirección de respuesta, si queremos que sea distinta que la del remitente 
			$headers .= "Reply-To: conoelmarginado@outlook.com\r\n"; 
			//ruta del mensaje desde origen a destino 
			$headers .= "Return-path: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibián copia 
			$headers .= "Cc: conoelmarginado@outlook.com\r\n"; 
			//direcciones que recibirán copia oculta 
			$headers .= "Bcc: conoelmarginado@outlook.com\r\n"; 
			mail($destinatario,$asunto,$cuerpo,$headers);
			echo '<script>alert("Revise su correo")</script>
			  <script>window.location="index.php"</script>';
	
?>