<?php
	session_start();
	include "db.php";
	if(	$_SESSION['name'] == "Admin"){ //Admin
		$_SESSION['tipo'] = "admin";
		$_SESSION['id'] = 1;
		$_SESSION['user'] = "admin";
		header("Location: inicio_admin.php");
	}else{ //user
		$id = $_SESSION['sessClientesID'];
		$consulta = $conexion->query("SELECT * FROM `clientes` WHERE `id` = '$id'");
		$res = $consulta->fetch_array();
		$_SESSION['id'] = $res['id'];
		$_SESSION['name'] = $res['name'];
		$_SESSION['email'] = $res['email'];
		$_SESSION['tipo'] = "user";
		header("Location: inicio.php");
	}
?>