<?php
	session_start();
	include "db.php";
	$id = $_SESSION['id'];
	$name = $_SESSION['name']; 
	$email = $_SESSION['email'];
	$tipo = $_SESSION['tipo'];
	///consultamos a la base
	$consulta = "SELECT * FROM `chat`,`clientes` WHERE chat.id_user = '$id' and clientes.id = '$id' ORDER BY id_chat DESC Limit 10  ";
	$ejecutar = $conexion->query($consulta); 
	if($fila = $ejecutar->fetch_array()){
		do{ 
			$msj = "";
			$color = "";
			if($fila['envio'] == "user"){
				$msj = $name;
				$color = "#1def05";
			}else{
				$msj = "Admin";
				$color = "#f90655";
			}
		?>
		<div id="datos-chat">
				<span style="color: <?php echo $color; ?>;"><?php echo $msj; ?></span>
		 		<span style="color: #1C62C4;"><?php echo $fila['mensaje'];?></span>
				<span style="color: #848484;"><?php echo $fila['hora']; ?></span>
		</div>
		
		<?php 
		}while($fila = $ejecutar->fetch_array()); }
	else{
	?>
			<span style="color: #1C62C4;"><?php echo $name.' '; ?>inicia chat con nuestro Administrador</span>
			<span style="color: #848484;"></span>
	<?php
		}
	?>
