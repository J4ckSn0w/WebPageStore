<?php
	session_start();
	include "db.php";
	$tipo = $_SESSION['tipo'];
	$id = $_SESSION['id'];
	$user = $_SESSION['user'];
	$id_user = $_GET['id_user'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Chat</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link href="https://fonts.googleapis.com/css?family=Mukta+Vaani" rel="stylesheet">

	<script type="text/javascript">
		function ajax(){
			var req = new XMLHttpRequest();
			req.onreadystatechange = function(){
				if (req.readyState == 4 && req.status == 200) {
					document.getElementById('chat').innerHTML = req.responseText;
				}
			}
			req.open('GET', 'chat_admin2.php?id_user=<?php echo $id_user; ?>', true);
			req.send();
		}

		//linea que hace que se refreseque la pagina cada segundo
		setInterval(function(){ajax();}, 1000);
	</script>
</head>
<body onload="ajax();">

	<div id="contenedor">
		<div id="caja-chat">
			<div id="chat"></div>
		</div>

		<form method="POST" action="chat_admin.php?id_user=<?php echo $id_user; ?>">		
			<textarea name="mensaje" placeholder="Ingresa tu mensaje" ></textarea>
			<input type="submit" name="enviar" id="btn" value="Enviar">
		</form>
		
		
		<h1>
			<a href="inicio_admin.php" >Regresar</a>
			<a href="salir.php">Salir</a>
		</h1>
		<?php
			if (isset($_POST['enviar'])) {
				$mensaje = $_POST['mensaje'];
				if($mensaje!=""){
					$fecha = date("Y/m/d");
					$hora = date("h:i:sa");
					$consulta = "INSERT INTO `chat`( `id_admin`, `id_user`, `mensaje`, `envio`, `fecha`, `hora`) VALUES (1,$id_user,'$mensaje','$tipo','$fecha','$hora')";
					$ejecutar = $conexion->query($consulta);
					if ($ejecutar) {
						echo "<embed loop='false' src='beep.mp3' hidden='true' autoplay='true'>";
					}
			 	}
			}
		?>
	</div>

</body>
</html>