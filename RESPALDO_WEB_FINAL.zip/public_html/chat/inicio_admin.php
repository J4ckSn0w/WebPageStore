<?php
	session_start();
	include "db.php";
	$tipo = $_SESSION['tipo'];
	$id = $_SESSION['id'];
	$user = $_SESSION['user'];

?>
<!DOCTYPE html>
<html>
<head >
	<title>LOGIN CHAT</title>
	<link rel="stylesheet" type="text/css" href="estilos.css">
	<link href="https://fonts.googleapis.com/css?family=Mukta+Vaani" rel="stylesheet">
	<script type="text/javascript">
		function login(){
			var user = document.getElementById("user").value;
			var pass = document.getElementById("pass").value;
			window.location.href = "login.php?user="+user+"&pass="+pass;
		}
	</script>
</head>
<body>
	<div id="contenedor">
		<div id="caja-chat">
			<?php
				$consulta = $conexion->query("SELECT DISTINCT `id_user` FROM `chat` ");
				if($res = $consulta->fetch_array()){
					do{
						$id_user = $res['id_user'];
						$c = $conexion->query("SELECT * FROM `clientes` WHERE `id` = '$id_user'");
						$f = $c->fetch_array();
						$name = $f['name'];
						?>
						<a href="chat_admin.php?id_user=<?php echo $id_user; ?>">
							<span style="color: #f90655;">Chat con <?php echo $name; ?></span>
						</a><br>
						<?php
					}while($res = $consulta->fetch_array());
				}else{
					?>
						<span style="color: #f90655;">No hay chats</span><br>
					<?php
				}
			?>
		</div>

		<h1><a href="salir.php">Salir</a></h1>
	</div>
	</script>
</body>
</html>