<?php

$servidor = "localhost";
$usuario= "id8066023_conomarginado";
$password = "Losfuantitis";
$base_datos = "id8066023_juanpistore";
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

?>