<?php
	session_start();
	include "db.php";
	$tipo = $_SESSION['tipo'];
	$id = $_SESSION['id'];
	$user = $_SESSION['user'];
	$id_user = $_GET['id_user'];
	///consultamos a la base
	$consulta = "SELECT * FROM `chat`,`clientes` WHERE chat.id_user = '$id_user' and clientes.id = '$id_user' ORDER BY id_chat DESC Limit 10 ";
	$ejecutar = $conexion->query($consulta); 
	if($fila = $ejecutar->fetch_array()){
		$cs = $conexion->query("SELECT * FROM `clientes` WHERE `id` = '$id_user'");
		$f = $cs->fetch_array();
		$name = $f['name'];
		do{ 
			$msj = "";
			$color = "";
			if($fila['envio'] == "user"){
				$msj = $name;
				$color = "#1def05";
			}else{
				$msj = "Admin";
				$color = "#f90655";
			} 
		?>
		<div id="datos-chat">
				<span style="color: <?php echo $color; ?>;"><?php echo $msj; ?></span>
		 		<span style="color: #1C62C4;"><?php echo $fila['mensaje'];?></span>
				<span style="color: #848484;"><?php echo $fila['hora']; ?></span>
		</div>
		
		<?php 
		}while($fila = $ejecutar->fetch_array()); }
	else{
	?>
			<span style="color: #1C62C4;"><?php echo $name.' '; ?>No hay mensajes</span>
			<span style="color: #848484;"></span>
	<?php
		}
	