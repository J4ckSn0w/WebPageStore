<?php
	session_start();
	include "db.php";
	if($_GET['user'] != '' &&  $_GET['pass'] != ''){
		$user = $_GET['user'];
		$pass = md5($_GET['pass']);
		$consulta = $conexion->query("SELECT * FROM `clientes` WHERE `email` = '$user' AND `password` = '$pass' ");
		if($res = $consulta->fetch_array()){
			$_SESSION['id'] = $res['id'];
			$_SESSION['name'] = $res['name'];
			$_SESSION['email'] = $res['email'];
			$_SESSION['tipo'] = "user";
			header("Location: inicio.php");	
		}else{
			$consulta2 = $conexion->query("SELECT * FROM `admin` WHERE `user` = '$user' AND `pass` = '$pass'");
			if($res2 = $consulta2->fetch_array()){
				$_SESSION['tipo'] = "admin";
				$_SESSION['id'] = $res['id'];
				$_SESSION['user'] = $res['user'];
				header("Location: inicio_admin.php");
			}else{
				session_destroy();
				header("Location: index.php");
			}
		}	
	}else{
		session_destroy();
		header("Location: index.php");
	}
	

	
?>