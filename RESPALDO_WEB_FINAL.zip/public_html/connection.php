<?php
    //$connection = mysqli_connect('localhost', 'root', '', 'bd_web');
    
    include 'pruebas_cono/chat_ajax/db.php';

    if(isset($_POST['name']))
    {
    	$id = $_POST['id'];
    	$name = $_POST['name'];
    	$descp = $_POST['descp'];
    	$precio = $_POST['precio'];
    	$cat = $_POST['cat'];
    	$existencia = $_POST['existencia'];
        $imagen = $_POST['imagen'];
        date_default_timezone_set('America/Mexico_City');
        $fecha = date("Y-m-d H:i:s");

    	//Actualizar info de base de datos
    	$result = $conexion->query("UPDATE productos SET name='$name', description='$descp', price='$precio', id_category ='$cat', existencia='$existencia)', imagen = '$imagen', modified = '$fecha' WHERE id='$id'");
    	if($result)
    	{
    		return "data updated";
    	}
    }
?>