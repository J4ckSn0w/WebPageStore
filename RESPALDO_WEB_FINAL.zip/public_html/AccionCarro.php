<?php
//inicializar las clases
include 'Carro.php';
$carro = new Carro;

//establecer conexion con la base de datos
include 'pruebas_cono/chat_ajax/db.php';
if(isset($_REQUEST['action']) && !empty($_REQUEST['action'])){
	if($_REQUEST['action'] == 'addToCart' && !empty($_REQUEST['id']) ){
		//si se envio unapeticion de poner en el carrito se obtienen sus detalle para agregarlo al carro
		$productID=$_REQUEST['id'];
        $precios=$_REQUEST['precio'];
		$query=$conexion->query("SELECT * FROM productos WHERE id =".$productID);
		$row=$query->fetch_assoc();//recupera una lista de resultados
		$itemData= array(
			'id'=> $row['id'],
			'name'=> $row['name'],
			//'price'=> $row['price'],
            'price'=> $precios,
             'existencia'=>$row['existencia'],
			'qty' => 1
		);

		$insertItem = $carro->insert($itemData);
		//lo agrega y regresa un boolean
		$redirectLoc= $insertItem?'verCarrito.php':'index.php';
		//header("location:checkout.php");
		header("Location:".$redirectLoc);// lo direcciona dependiendo del resultado


	}elseif($_REQUEST['action'] == 'updateCartItem' && !empty($_REQUEST['id'])){
		 $itemData = array(
            'rowid' => $_REQUEST['id'],
            'qty' => $_REQUEST['qty']
        );
        $updateItem = $carro->update($itemData);
        
        echo $updateItem?'ok':'err';die;
	}//si se quiere eliminar el articulo

	elseif($_REQUEST['action'] == 'removeCartItem' && !empty($_REQUEST['id'])){
         $deleteItem = $carro->remove($_REQUEST['id']);
        header("Location: verCarrito.php");
    }else{
        header("Location: index.php");
    }
}else{
    header("Location: index.php");
}//else del de hasta arriba
	
