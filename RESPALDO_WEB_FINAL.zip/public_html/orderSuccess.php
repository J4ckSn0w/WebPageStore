<?php
//if(!isset($_REQUEST['id'])){
  //alert("no llego");
    //header("Location: index.php");
//}
include 'pruebas_cono/chat_ajax/db.php';
include 'Carro.php';
$carro = new Carro;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <title>Envio Exitoso</title>
    <meta charset="utf-8">
    <style>
    .container{width: 100%;padding: 50px;}
   
    </style>
</head>
</head>
<body>
<div class="container">
    <h1>Enviando...</h1>


    <?php
    $accion=$_POST['action'];
    if($accion== 'placeOrder' && $carro->total_items() > 0 && !empty($_SESSION['sessClientesID'])){
        // insert order details into database
        $insertOrder = $conexion->query("INSERT INTO orden (clientes_id, total_price, created, modified) VALUES ('".$_SESSION['sessClientesID']."', '".$carro->total()."', '".date("Y-m-d H:i:s")."', '".date("Y-m-d H:i:s")."')");//guarda en la base de datos en la tabla de ordenes
        
        if($insertOrder){
            $orderID = $conexion->insert_id;
            $sql = '';
            // get cart items
            $cartItems = $carro->contenido();
            foreach($cartItems as $item){
                $id=$item['id'];
                $vendido=$item['qty'];
                $existencia=$item['existencia']-$item['qty'];
                $sql .= "INSERT INTO `detalle_orden` (`orden_id`, `product_id`, `quantity`) VALUES ('".$orderID."', '".$item['id']."', '".$item['qty']."');";
                $result = $conexion->query("UPDATE productos SET existencia='$existencia)' WHERE id='$id'");
              
            }
            // insert order items into database
            $insertOrderItems = $conexion->multi_query($sql);
            //multiquery lo agrega a la base de datos
            if($insertOrderItems){
                $carro->destroy();
            }else{
                header("Location: checkout.php");
            }
        }else{

            header("Location: index.php");
        }
        //del de insert order
    }
    ?>
   <h1>Tu pedido fue exitoso con el pedido:<?php echo $orderID; ?></h1>
   <p> Pronto llegara </p>
   	<!--aqui se puede mandar llamar al metodo para enviar el correo pues es aqui donde se guarda en la base de datos-->

<a href="index.php">Regresar al inicio</a>
</div>
</body>
</html>