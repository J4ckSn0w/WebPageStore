<?php
 session_start();
class Carro {
	protected $contenido_carro = array();
	protected $total;
	public function __construct(){// se pone doble guin bajo para el construftor morros
		//si esta la session abierta se crea la instancia sino no
		$this->contenido_carro = !empty($_SESSION['contenido_carro'])?$_SESSION['contenido_carro']:NULL;
		if($this->contenido_carro === NULL){
			//poner valores si el carro esta vacio en ceros
			$this->contenido_carro=array('carro_total'=> 0,'total_items'=> 0);
			$this->total=0;
		}

	}

	//contenido carro regresara el contenido total del carrito en forma de array

	public function set_totalPrecio($valor){
		$this->total=$valor;
	}

	public function contenido(){
		$carro = array_reverse($this->contenido_carro);
		// se van a remorver de la tabla carro asi que no se borraran de contenido carro

		unset($carro['total_items']);
		unset($carro['carro_total']);
		return $carro;
	}

	//regresa cualquier item seleccionado llega un string y regresa el array del objeto seleccionado'
	public function get_item($articulo){
		return (in_array($articulo,array('total_items','carro_total'),TRUE) OR !isset($this->contenido_carro[$articulo]))? FALSE: $this->contenido_carro[$articulo];
		//esta funcion hace una busqueda estricta de que el producto se encuentre dentro del array list

	}

	//la siguiente funcion regresa el total del precio
	public function total(){
		return $this->contenido_carro['carro_total'];
	}
	//regresa el total de productos en el carro
	public function total_items(){
		return $this->contenido_carro['total_items'];
	}
	public function total_precio_total(){
		return $this->total;
	}
	// la siguiente funcion de insertar lo que realiza es subirlo a la base de datos y guardarlo para la sesion recibe un array y regresa el booleano

	public function insert($item = array()){
		if(!is_array($item)  OR count($item) === 0){
			//si el array esta vacio regresa falso
			return FALSE;
		}
		else{
			if(!isset($item['id'],$item['name'],$item['price'],$item['qty'])){
				//si no estan definidas estas cosas se regresa falso tambien
				return FALSE;
			}else{
				//insercion del array a la base de datos y al carrito
				$item['qty']= (float) $item['qty'];//lo convierte a float
				if($item['qty'] == 0){
					return FALSE;//si la cantidad es cero regresa falso
				}
				$item['price']= (float) $item['price'];
				//se crea una variable para unicamente el precio
				$rowid=md5($item['id']);//le realiza un hash 

				  $old_qty = isset($this->contenido_carro[$rowid]['qty']) ? (int) $this->contenido_carro[$rowid]['qty'] : 0;
                // re-create the entry with unique identifier and updated quantity
                $item['rowid'] = $rowid;
                $item['qty'] += $old_qty;
                $this->contenido_carro[$rowid] = $item;
				//salvar contenido del carro
				if($this->save_cart()){
					return isset($rowid) ? $rowid :TRUE;
				}else{
					return FALSE;
				}
			}
		}
	}
	 public function update($item = array()){
        if (!is_array($item) OR count($item) === 0){
            return FALSE;
        }else{
            if (!isset($item['rowid'], $this->contenido_carro[$item['rowid']])){
                return FALSE;
            }else{
                // prep the quantity
                if(isset($item['qty'])){
                    $item['qty'] = (float) $item['qty'];
                    // remove the item from the cart, if quantity is zero
                    if ($item['qty'] == 0){
                        unset($this->contenido_carro[$item['rowid']]);
                        return TRUE;
                    }
                }
                
                // find updatable keys
                $keys = array_intersect(array_keys($this->contenido_carro[$item['rowid']]), array_keys($item));
                // prep the price
                if(isset($item['price'])){
                    $item['price'] = (float) $item['price'];
                }
                // product id & name shouldn't be changed
                foreach(array_diff($keys, array('id', 'name')) as $key){
                	   $this->contenido_carro[$item['rowid']][$key] = $item[$key];
                   
                }
                // save cart data
                $this->save_cart();
                return TRUE;
            }
        }
    }
  
    protected function save_cart(){
    	$suma=0;
        $this->contenido_carro['total_items'] = 0;
        $this->cart_contents['carro_total'] = 0;
        foreach ($this->contenido_carro as $key => $val){
            // make sure the array contains the proper indexes
            if(!is_array($val) OR !isset($val['price'], $val['qty'])){
                continue;
            }
     		$suma +=($val['price'] * $val['qty']);
           // $this->contenido_carro['carro_total'] += ($val['price'] * $val['qty']);
            $this->contenido_carro['total_items'] += $val['qty'];
         	$this->contenido_carro[$key]['subtotal'] = ($this->contenido_carro[$key]['price'] * $this->contenido_carro[$key]['qty']);
        }
        $this->contenido_carro['carro_total']= (float)$suma;
        
         
        // if cart empty, delete it from the session
        if(count($this->contenido_carro) <= 2){
            unset($_SESSION['contenido_carro']);
            return FALSE;
        }else{
            $_SESSION['contenido_carro'] = $this->contenido_carro;
            return TRUE;
        }
    }
    
    
     public function remove($row_id){
        // unset & save
        unset($this->contenido_carro[$row_id]);

        $this->save_cart();
        return TRUE;
     }
     

	
	//destruir todo
	public function destroy(){
		$this->contenido_carro=array('carro_total'=>0,'total_items'=>0);
		unset($_SESSION['contenido_carro']);//elimina la variable de sesion
	}
}